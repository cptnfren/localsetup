# Backlog

*Last updated: 2026-02-25*

## Overdue

(none)

## Due soon (next 7 days)

(none)

## No date (whenever)

- [ ] Revisit X11 configuration – Use case: OpenClaw Agent drives browser on server; human on Windows may need to monitor/intervene (e.g. captcha). Notes: `docs/ops/x11-forwarding-notes.md` (Windows X server install, ssh -X, server/client setup).

## Done

(none)

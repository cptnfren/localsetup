# Contributing to Localsetup v2

Thank you for your interest in contributing. Here’s how to get started.

## How to contribute

- **Bug reports and feature requests**  - Open an [Issue](https://github.com/cptnfren/localsetup/issues).
- **Questions and ideas**  - Use [Discussions](https://github.com/cptnfren/localsetup/discussions).
- **Code or docs changes**  - Open a Pull Request against `main`. Please keep the scope focused and reference any related Issues.

## What to expect

- We’ll review your Issue or PR and respond when we can.
- For framework changes (new skills, tools, or workflow behavior), we may ask for a short rationale or use case so we can keep the project consistent.
- By contributing, you agree that your contributions will be licensed under the same [MIT License](LICENSE) as the project.

## Repository layout

- **Root**  - Install scripts (`install`, `install.ps1`), README, LICENSE, versioning scripts, and docs.
- **`framework/`**  - The engine: `tools/`, `lib/`, `skills/`, `templates/`, `docs/`. Changes here affect what gets deployed into a client’s `_localsetup/`.
- **`.githooks/`**  - Git hooks (e.g. commit-msg for version bump). Run `./scripts/install-githooks` once per clone to use them.

For detailed structure and conventions, see [framework/README.md](framework/README.md) and the docs under `framework/docs/`.

## Code and docs standards

- **Scripts:** Bash and PowerShell; keep cross-platform in mind where relevant.
- **Skills:** Follow the [Agent Skills](https://agentskills.io/specification) spec (SKILL.md with `name` and `description` frontmatter).
- **Docs:** Markdown; use clear headings and relative links. Framework docs live under `framework/docs/` and are copied to `_localsetup/docs/` on deploy.

If you have questions, open a Discussion and we’ll be happy to clarify.

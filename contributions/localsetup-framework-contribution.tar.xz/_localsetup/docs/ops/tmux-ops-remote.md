# Tmux ops tool: remote (VMs, SSH, Docker)

**Purpose:** Use the tmux_ops workflow when the tmux server runs on a different host than where you run the command (e.g. Cursor on laptop, tmux on a VM or remote server).

## Config

- **REMOTE_TMUX_HOST** – Hostname or IP of the machine where tmux runs. When set, the `tmux_ops` wrapper runs the Python tool over SSH on that host and returns the same JSON.
- **REMOTE_TMUX_CWD** – (Optional) Repo path on the remote. Default: `/opt/devzone/devops`.

## Usage

From repo root (with Cursor/agent on your laptop):

```bash
export REMOTE_TMUX_HOST=sh0t
./_localsetup/tools/tmux_ops pick
./_localsetup/tools/tmux_ops probe -t ops
```

When REMOTE_TMUX_HOST is set, run all tmux commands (send-keys, capture-pane) on that host via SSH, e.g.:

```bash
ssh "$REMOTE_TMUX_HOST" "tmux send-keys -t ops 'sudo apt update' Enter"
```

Log paths and session names are the same; they refer to paths and sessions on the remote host.

## When not to set it

If you use Cursor Remote SSH and the agent runs on the same host as tmux, do **not** set REMOTE_TMUX_HOST. Run `tmux_ops` and `tmux send-keys` directly.

## Reference

- Skill: **localsetup-tmux-shared-session-workflow**
- Tool: `_localsetup/tools/tmux_ops` (pick, probe -t SESSION)

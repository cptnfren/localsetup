---
status: ACTIVE
version: 2.0
---

# Skill importing (Localsetup v2)

**Purpose:** How to import external skills from a URL (e.g. GitHub) or local path: discover skills, validate and screen for safety, summarize for the user, and let them choose which to import. Compatible with [Agent Skills](https://agentskills.io/specification) and sources like [Anthropic's skills](https://github.com/anthropics/skills).

## Sources

- **URL**  - GitHub repo (e.g. `https://github.com/anthropics/skills`), raw archive URL, or any HTTP(S) URL the agent can fetch. The agent clones or downloads to a temporary directory, then runs the scan tool on that path.
- **Local path**  - Directory on disk (e.g. `./downloaded-skills/skills/`) containing one or more skill directories.
- **Local markdown**  - A single SKILL.md or a doc the user wants turned into a skill; use the [skill-creator](SKILL_INTEROPERABILITY.md) workflow to create a new skill from it.

## Workflow (agent-driven)

1. **Obtain content**  - If URL: clone repo (e.g. `git clone --depth 1 <url> <tmpdir>`) or download archive and extract. If local path: use it as the scan root.
2. **Discover skills**  - Run the framework scan tool on the root path. It finds directories that contain `SKILL.md` with valid frontmatter (`name`, `description`).
3. **Validate and screen**  - For each candidate skill the tool:
   - Validates Agent Skills format (name matches directory, description present).
   - Lists what the skill has: files in `scripts/`, `references/`, `assets/`; types of code (e.g. Python, Bash).
   - Runs a heuristic security screen (no execution): flags patterns that could indicate malicious intent (e.g. `eval` of untrusted input, `curl | sh`, encoded payloads, credential exfiltration). Results are advisory; the user decides.
4. **Summarize per skill**  - For each skill produce a brief:
   - **What it does**  - From `description` (and first paragraph of body if helpful).
   - **What it has**  - File count and types (scripts, references, assets); list script languages and notable files.
   - **Code / behavior**  - Kinds of code (Python, Bash, etc.) and any compatibility or dependency notes.
   - **Security screening**  - Pass / flags (e.g. "no concerns" or "review: pattern X in file Y"). Do not auto-block; present so the user can choose.
5. **User selects**  - Present the list and briefs; ask the user which skills to import (by name or "all"). Use AskQuestion or clear prompt so they can approve or skip.
6. **Duplicate, overlap, and namespace check**  - Before importing each selected skill, compare it to existing framework skills (list `framework/skills/` and read each existing SKILL.md `name` and `description`). For each candidate:
   - **Namespace collision:** Same `name` or same directory name already exists in `framework/skills/`. Warn the user and offer: **Ignore new** (skip this skill), **Replace existing** (overwrite with the new skill), **Merge** (combine best of both into one skill), or **Create as new** (import under a different name, e.g. `localsetup-<name>-v2`).
   - **Possible duplicate/overlap:** No name match but description or purpose is very similar to an existing skill (same domain, same triggers, overlapping "when to use"). Warn that overlap is likely and offer the same four options: **Ignore new**, **Replace existing**, **Merge**, or **Create as new** (user can confirm or pick a distinct name).
7. **Import selected**  - For each selected skill, after user choice (and any merge/rename): copy the skill directory into `framework/skills/<name>/`; optionally rename to `localsetup-<name>` and set `name` in frontmatter; add `metadata.version: "1.0"` if missing; register per [PLATFORM_REGISTRY.md](PLATFORM_REGISTRY.md); run deploy if needed.

## Security screening (heuristic, no execution)

- **Scope**  - Static scan of file contents only. No execution of scripts or network calls by the tool.
- **Patterns to flag (examples)**  - `eval(`, `base64 -d` piped to shell, `curl | sh`, `wget -O- | bash`, `Invoke-Expression`, hardcoded secrets or token-like strings, scripts that write outside the skill dir or change system config without clear purpose. Flag for user review rather than block.
- **Output**  - Each skill gets a brief "Security" line: e.g. "No concerns" or "Review: eval in scripts/foo.py line N."

## Tool

- **Scan only (no fetch):** `_localsetup/tools/skill_importer_scan` (Bash) or `skill_importer_scan.ps1` (PowerShell). Run from repo root. Arguments: path to directory that may contain skill subdirs. Writes a per-skill summary (what it does, what it has, code types, security flags) to stdout (and optionally JSON to a file). The agent uses this after fetching a URL to a temp dir.
- **Fetch**  - The agent uses `git clone`, `curl`, or equivalent to obtain the URL content; then runs the scan tool on the resulting path.

## Duplicate, overlap, and namespace checks

- **Before importing,** the agent must check each candidate against existing framework skills so the user can avoid duplicates and naming conflicts.
- **How to check:** List existing skills from `framework/skills/` (directory names and, for each, the `name` and `description` from SKILL.md frontmatter). Compare each selected candidate by (1) exact `name` or directory name, (2) similarity of description/purpose/triggers.
- **Namespace collision:** Candidate has the same `name` or same directory name as an existing skill. Always warn and offer: **Ignore new** (do not import), **Replace existing** (overwrite), **Merge** (combine best of both), **Create as new** (import with a different name).
- **High overlap:** No name match but the candidate is very similar in purpose/triggers to an existing skill. Warn that duplication/overlap is likely and offer the same four options. For **Merge**, the agent combines content from both (e.g. stronger description, merged sections, deduplicated steps) into one skill and replaces the existing one; then the incoming skill is not added as a second copy.
- **User choice is final.** Do not auto-replace or auto-merge without explicit user selection.

## Compatibility

- Imported skills must be [Agent Skills](https://agentskills.io/specification)–compliant (SKILL.md with `name`, `description`). The scan tool checks for this. After import, they work like any framework skill and are interchangeable (see [SKILL_INTEROPERABILITY.md](SKILL_INTEROPERABILITY.md)).

## Reference

- [SKILL_INTEROPERABILITY.md](SKILL_INTEROPERABILITY.md)  - Import/export and spec alignment.
- [PLATFORM_REGISTRY.md](PLATFORM_REGISTRY.md)  - Where to register newly imported skills.
- Load skill **localsetup-skill-importer** when the user wants to import skills from a URL or local path, or when screening and selecting external skills.

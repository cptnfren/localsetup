# Localsetup v2

**Version:** 2.0.8  
**Last updated:** 2026-02-18

Localsetup v2 is a universal, cross-platform agentic workflow engine that lets you manage local and remote systems with your favorite AI agent -Cursor, Claude Code, OpenAI Codex CLI, or OpenClaw. Use it for DevOps on your local PC or remote servers, network configuration, release and deployment workflows, or any task where you want structured agent help while keeping full transparency, security, and traceability.

The framework is for anyone who wants to execute tasks with agents: it provides a convenient, contained place for workflows and skills. It is **lightweight** and **does not interfere with existing projects** -everything lives under a single directory and a few platform paths. Use it for a **wide variety of tasks**; it is **compatible with all agentic design patterns** and, most importantly, **platform-independent**: the same skills and workflows work across Cursor, Claude Code, Codex, OpenClaw, and any Agent Skills–compliant host.

The framework deploys into your repo: everything lives under `_localsetup/` and platform-specific paths at repo root, so the setup is mobile and backup-able. You get a single source of context and skills that agents load by task -decision trees, PRD batches, safety and backup, tmux shared sessions, versioning, publishing, and more. Use the built-in skills as-is, **create new skills** from your workflow or from existing docs (skill-creator), or **import external skills** from a URL (e.g. GitHub) or local path: the framework discovers and validates them, runs a heuristic security screen, and summarizes each so you choose which to import (skill-importer). Skills follow the [Agent Skills](https://agentskills.io/specification) specification and are **interchangeable** -you can use skills from ecosystems like [Anthropic's skills](https://github.com/anthropics/skills) here, and use this framework's skills in any spec-compliant host. Emphasis is on transparent operations, safe defaults (including human-in-the-loop for destructive or sudo actions), high-quality scripts and docs, and git-coupled traceability for PRDs, specs, and outcomes.

**Use cases:** DevOps and local/remote system management; network and release workflows; creating new skills from your workflow or from existing markdown; importing skills from a GitHub repo or URL (with discovery, validation, security screening, and your choice of which to add); publishing to GitHub with a repeatable checklist; automatic versioning from commit messages; and using the same skills across Cursor, Claude Code, Codex, and OpenClaw or in any [Agent Skills](https://agentskills.io/specification)–compliant host.

### Summary of features

- **One-line install** for Linux/macOS (Bash) and Windows (PowerShell); supports Cursor, Claude Code, OpenAI Codex CLI, and OpenClaw. Deploy into any repo; everything lives under `_localsetup/` and platform paths (e.g. `.cursor/rules/`, `.cursor/skills/`).
- **Agent Skills compliant:** Skills follow the [Agent Skills](https://agentskills.io/specification) spec and are interchangeable with [Anthropic's skills](https://github.com/anthropics/skills) and other spec-compliant hosts.
- **Built-in skills:** Decision tree workflow, Agent Q / PRD batch, umbrella queue, safety and backup, tmux shared session, automatic versioning, GitHub publishing checklist, public repo identity, framework compliance, script-and-docs quality, communication and tools, plus **skill-creator** (create skills from workflow or docs) and **skill-importer** (import from URL or local path with discovery, validation, and heuristic security screening).
- **Skill discovery:** Public skill registry (`PUBLIC_SKILL_REGISTRY.urls`) and index (`PUBLIC_SKILL_INDEX.yaml`); recommend top 5 similar public skills when creating or importing; options to get in-depth summary, use a public skill, continue on your own, or adapt. Index refresh prompts (7-day default); project repo maintains its own copy; users can download from the repo or maintain their own.
- **Duplicate and overlap handling:** When creating or importing a skill, check for namespace collision and similar existing skills; offer keep existing, replace, merge, or create as new.
- **Versioning:** Repo `VERSION` plus optional Git hooks (Conventional Commits: `feat:` / `fix:` / `docs:` drive bump); READMEs and docs stay in sync; per-skill `metadata.version` auto-bump on commit.
- **Cross-platform tooling:** Bash and PowerShell for install, deploy, `skill_importer_scan`, version bump, and githooks; OS detection for Linux, macOS, Windows.
- **Docs and traceability:** PRD schema, outcome template, git-coupled references for PRDs/specs/outcomes, publishing checklist, multi-platform install, and platform registry as single source of truth.

---

## Contents

| Section | Description |
|--------|-------------|
| [Summary of features](#summary-of-features) | What the framework provides today |
| [Install](#-install) | One-line install and full command-line reference (parameters, tools, examples) |
| [Layout](#-layout) | What gets deployed |
| [Versioning](#-versioning) | Auto-bump from commit messages |
| [Docs](#-docs) | Framework documentation |
| [License](#-license-and-copyright) | MIT and copyright |
| [Author](#-author) | Contact and company |

---

## 📦 Install

**Linux / macOS** (from your client repo root). Recommended one-liner (no prompts):

```bash
curl -sSL https://raw.githubusercontent.com/cptnfren/localsetup/main/install | bash -s -- --directory . --tools cursor --yes
```

Interactive (prompts for directory and tools):

```bash
curl -sSL https://raw.githubusercontent.com/cptnfren/localsetup/main/install | bash
```

If the interactive run shows "Directory does not exist" or a sed error, use the recommended one-liner above or bypass cache: add `?nocache=$(date +%s)` to the URL.

**Windows** (PowerShell; clone or download this repo first, then from repo root):

```powershell
.\install.ps1 -Directory . -Tools cursor -Yes
```

Supported platforms (canonical list in [framework/docs/PLATFORM_REGISTRY.md](framework/docs/PLATFORM_REGISTRY.md)): Cursor, Claude Code, OpenAI Codex CLI, OpenClaw. Use `--tools` / `-Tools` to select one or more (e.g. `--tools cursor,claude-code`). Framework tooling is cross-platform: Bash on Linux/macOS, PowerShell on Windows; see [framework/docs/MULTI_PLATFORM_INSTALL.md](framework/docs/MULTI_PLATFORM_INSTALL.md).

### Install: command-line reference

Use a **dedicated help switch** to show options and exit without installing:

- **Bash:** `./install --help` or `./install -h`
- **PowerShell:** `.\install.ps1 -Help` or `.\install.ps1 -?` or `.\install.ps1 -h`

If you pass an unknown option, a missing value, or an invalid tool name, the script prints an error and the same help text, then exits with a non-zero code.

#### Parameters and switches

| Parameter | Bash | PowerShell | Description |
|-----------|------|------------|-------------|
| **Directory** | `--directory PATH` | `-Directory PATH` | Client repo root where `_localsetup/` will be created. Must exist. Default: current directory (or prompt in interactive mode). |
| **Tools** | `--tools LIST` | `-Tools LIST` | Comma-separated list of platforms to install. **Required** when using non-interactive mode. See [Tools (platforms)](#tools-platforms) below. |
| **Non-interactive** | `--yes` | `-Yes` | Skip all prompts. Requires `--tools` / `-Tools`. Use for CI or scripts. |
| **Help** | `--help`, `-h` | `-Help`, `-?`, `-h` | Print usage and options, then exit. No install is performed. |

#### Tools (platforms)

Each value selects which agent platform(s) get context and skills deployed. You can specify one or more, comma-separated. Numeric shortcuts `1`–`4` are accepted in interactive mode only.

| Tool | Description | What gets deployed |
|------|-------------|---------------------|
| **cursor** | Cursor IDE | `.cursor/rules/` (master rule + index), `.cursor/skills/localsetup-*/` |
| **claude-code** | Claude Code | `.claude/CLAUDE.md`, `.claude/skills/localsetup-*/` |
| **codex** | OpenAI Codex CLI | `AGENTS.md` at repo root, `.agents/skills/localsetup-*/` |
| **openclaw** | OpenClaw | `skills/localsetup-*/`, `_localsetup/docs/OPENCLAW_CONTEXT.md` |

#### What happens when you run install

1. **Directory**  - Resolved to an absolute path; must exist (script exits with help if it does not).
2. **Tools**  - In interactive mode you are prompted for a comma-separated list; in non-interactive mode `--tools` / `-Tools` is required. Each value is validated (must be one of the four tools above); invalid values cause an error and help.
3. **Clone or update**  - If `_localsetup/` already exists and is a Git repo, `git pull --rebase` is run. Otherwise the framework is cloned from the default repo (overridable with `LOCALSETUP_2_REPO`).
4. **Deploy**  - The deploy script runs with the chosen tools and root path, writing context files and copying skills into the platform-specific paths listed above.
5. **Done**  - A short message confirms the framework path and that platform files were written.

#### Example commands

```bash
# Bash: help only (no install)
./install --help
./install -h

# Bash: Cursor only, non-interactive
./install --directory . --tools cursor --yes

# Bash: Cursor + Claude Code
./install --tools cursor,claude-code --yes

# Bash: interactive (prompts for directory and tools)
./install
```

```powershell
# PowerShell: help only (no install)
.\install.ps1 -Help
.\install.ps1 -?

# PowerShell: Cursor only, non-interactive
.\install.ps1 -Directory . -Tools cursor -Yes

# PowerShell: multiple tools
.\install.ps1 -Tools "cursor,claude-code" -Yes
```

---

## 📁 Layout

After install, your repo contains:

- **`_localsetup/`**  - framework (tools, lib, skills, docs, templates)
- **Platform paths at repo root**  - e.g. `.cursor/rules/`, `.cursor/skills/` for Cursor

All context and framework state are repo-local; no home-directory dependency. Move or clone the repo and the framework goes with it.

---

## 🔢 Versioning

Version is stored in **VERSION** (semver). The displayed version **only auto-increments when Git hooks are installed**; otherwise it stays unchanged until you bump manually. When hooks are enabled, each commit bumps from your message (Conventional Commits: `feat:` → minor, `fix:` / `docs:` → patch, `BREAKING CHANGE:` → major) and READMEs/docs are updated in the same commit.

**Enable once per clone:**

```bash
./scripts/install-githooks
```

See [docs/VERSIONING.md](docs/VERSIONING.md) for details and manual bump commands.

---

## 📚 Docs

After installation, see **`_localsetup/docs/`** for the full framework documentation (workflows, skills, PRD schema, multi-platform install, and more).

- [Versioning](docs/VERSIONING.md)  - Repo VERSION bump and Git hooks; skill metadata.version auto-bump  
- [Publishing checklist](docs/PUBLISHING_CHECKLIST.md)  - Pre-publication scrub and repo readiness  
- [Security](SECURITY.md)  - How to report vulnerabilities  
- [Contributing](CONTRIBUTING.md)  - Issues, PRs, and standards  
- [License](LICENSE)  - MIT full text  
- [Framework README](framework/README.md)  - Engine layout, tools, skills  
- [Multi-platform install](framework/docs/MULTI_PLATFORM_INSTALL.md)  - Install for supported platforms  
- [Platform registry](framework/docs/PLATFORM_REGISTRY.md)  - Canonical list of supported AI agent platforms and paths  
- [Agent Skills compliance](framework/docs/AGENT_SKILLS_COMPLIANCE.md)  - Spec alignment and skill document versioning  
- [Skill interoperability](framework/docs/SKILL_INTEROPERABILITY.md)  - Import external skills; export framework skills; use in any spec-compliant host  
- [Skill importing](framework/docs/SKILL_IMPORTING.md)  - Import from URL or local path; discover, validate, security-screen, summarize; you pick which skills to add
- [Skill discovery](framework/docs/SKILL_DISCOVERY.md)  - Public skill registries; recommend similar public skills when creating or importing  

---

## 📜 License and copyright

Copyright (c) 2026 Crux Experts LLC. This project is released under the [MIT License](LICENSE). You may use, copy, modify, merge, publish, distribute, sublicense, and sell copies or derivative works of the Software, subject to including the above copyright notice and this permission notice in all copies or substantial portions. See [LICENSE](LICENSE) for the full text.

---

## 👤 Author

**cptnfren**  - [GitHub](https://github.com/cptnfren). To get in touch, open an [Issue](https://github.com/cptnfren/localsetup/issues) or [Discussion](https://github.com/cptnfren/localsetup/discussions) in this repo.

**[Crux Experts LLC](https://www.cruxexperts.com/)**  - Private business advisory, U.S. business establishment, reputation management, and technology advisory.

#!/usr/bin/env python3
# Purpose: Orchestrate ClamAV checks and profile-based scans; write compact YAML reports.
# Created: 2026-02-24
# Last updated: 2026-02-24

from __future__ import annotations

import argparse
import os
import shlex
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import yaml

PROFILE_DIR_DEFAULT = "av/profiles"
REPORT_ROOT_DEFAULT = "reports/clamav"


def _utc_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def _load_profile(profile_name: str, profiles_dir: Path) -> dict:
    path = profiles_dir / f"{profile_name}.yaml"
    if not path.is_file():
        raise FileNotFoundError(f"profile not found: {path}")
    raw = path.read_text(encoding="utf-8", errors="replace")
    data = yaml.safe_load(raw)
    if not isinstance(data, dict):
        raise ValueError(f"profile YAML must be a mapping: {path}")
    return data


def _find_binary(prefer_clamd: bool) -> tuple[str, str]:
    """Return (binary_name, path). prefer clamdscan when requested."""
    if prefer_clamd:
        for name in ("clamdscan", "clamscan"):
            path = shutil.which(name)
            if path:
                return name, path
    else:
        for name in ("clamscan", "clamdscan"):
            path = shutil.which(name)
            if path:
                return name, path
    return "", ""


def _build_scan_command(binary: str, profile: dict) -> str:
    paths = profile.get("paths") or []
    if not paths:
        raise ValueError("profile.paths must contain at least one path")
    exclude = profile.get("exclude_paths") or []
    extra_args = profile.get("extra_args") or []
    args: list[str] = [shlex.quote(binary), "-r"]
    for p in exclude:
        args.append(f"--exclude-dir={shlex.quote(str(p))}")
    for a in extra_args:
        args.append(shlex.quote(str(a)))
    for p in paths:
        args.append(shlex.quote(str(p)))
    return " ".join(args)


def cmd_check() -> int:
    binary, path = _find_binary(prefer_clamd=False)
    freshclam = shutil.which("freshclam")
    host = os.uname().nodename if hasattr(os, "uname") else "unknown"
    if not binary:
        print("ClamAV not detected (clamscan/clamdscan not found).", file=sys.stderr)
        print("Suggested install (Ubuntu, run inside shared tmux with sudo):", file=sys.stderr)
        print("  sudo apt update", file=sys.stderr)
        print("  sudo apt install clamav clamav-daemon clamav-freshclam", file=sys.stderr)
        return 1
    print(f"Host: {host}")
    print(f"Scanner: {binary} at {path}")
    if freshclam:
        print(f"freshclam: {freshclam}")
    else:
        print("freshclam not found in PATH (DB auto-updates may be disabled).")
    return 0


def cmd_list_profiles(profiles_dir: Path) -> int:
    if not profiles_dir.is_dir():
        print(f"No profiles dir: {profiles_dir}", file=sys.stderr)
        return 1
    for p in sorted(profiles_dir.glob("*.yaml")):
        try:
            data = yaml.safe_load(p.read_text(encoding="utf-8", errors="replace")) or {}
        except Exception:
            data = {}
        name = data.get("profile") or p.stem
        print(f"{name}: {p}")
    return 0


def _parse_summary(binary: str, stdout: str) -> dict:
    summary: dict[str, str] = {}
    for line in stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        lower = line.lower()
        if lower.startswith("known viruses:"):
            summary["known_viruses"] = line.split(":", 1)[1].strip()
        elif lower.startswith("engine version:"):
            summary["engine_version"] = line.split(":", 1)[1].strip()
        elif lower.startswith("scanned directories:"):
            summary["scanned_directories"] = line.split(":", 1)[1].strip()
        elif lower.startswith("scanned files:"):
            summary["scanned_files"] = line.split(":", 1)[1].strip()
        elif lower.startswith("infected files:"):
            summary["infected_files"] = line.split(":", 1)[1].strip()
        elif lower.startswith("data scanned:"):
            summary["data_scanned"] = line.split(":", 1)[1].strip()
        elif lower.startswith("data read:"):
            summary["data_read"] = line.split(":", 1)[1].strip()
        elif lower.startswith("time:"):
            summary["time"] = line.split(":", 1)[1].strip()
    summary["binary"] = binary
    return summary


def _collect_findings(stdout: str) -> list[str]:
    findings: list[str] = []
    for line in stdout.splitlines():
        if " FOUND" in line:
            findings.append(line.strip())
    return findings


def _render_markdown(report: dict) -> str:
    """Render a compact human-readable markdown summary for a scan."""
    profile = report.get("profile", "unknown")
    ts = report.get("timestamp_utc", "")
    host = report.get("host", "unknown")
    summary = report.get("summary") or {}
    findings = report.get("findings_raw") or []

    scanned_files = summary.get("scanned_files", "unknown")
    infected_files = summary.get("infected_files", "unknown")
    duration = summary.get("duration_seconds", summary.get("time", ""))

    lines: list[str] = []
    lines.append(f"# ClamAV scan summary ({profile})")
    lines.append("")
    lines.append(f"- Host: `{host}`")
    lines.append(f"- Time (UTC): `{ts}`")
    lines.append(f"- Profile: `{profile}`")
    lines.append(f"- Scanned files: `{scanned_files}`")
    lines.append(f"- Infected files: `{infected_files}`")
    if duration:
        lines.append(f"- Duration: `{duration}`")
    lines.append("")

    if findings:
        lines.append("## Detections")
        lines.append("")
        lines.append("| Path and signature |")
        lines.append("| ------------------- |")
        for f in findings:
            # Each finding line already contains path and signature text.
            safe = f.replace("|", "\\|")
            lines.append(f"| `{safe}` |")
    else:
        lines.append("No infected files were reported.")

    return "\n".join(lines) + "\n"


def cmd_scan(
    profile_name: str,
    profiles_dir: Path,
    report_root: Path,
    output_basename: str | None,
    repo_root: Path | None,
    write_markdown: bool,
) -> int:
    try:
        profile = _load_profile(profile_name, profiles_dir)
    except Exception as e:
        print(f"[clamav_ctl] {e}", file=sys.stderr)
        return 1

    use_clamd = bool(profile.get("use_clamd"))
    binary, path = _find_binary(prefer_clamd=use_clamd)
    if not binary:
        print("ClamAV scanner not found (clamscan/clamdscan).", file=sys.stderr)
        print("Install via OS packages (e.g. inside tmux with sudo):", file=sys.stderr)
        print("  sudo apt update", file=sys.stderr)
        print("  sudo apt install clamav clamav-daemon clamav-freshclam", file=sys.stderr)
        return 1

    cmd = _build_scan_command(path, profile)
    host = os.uname().nodename if hasattr(os, "uname") else "unknown"
    ts_utc = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    started = time.time()
    try:
        r = subprocess.run(
            cmd,
            shell=True,
            cwd=repo_root or Path.cwd(),
            capture_output=True,
            text=True,
            env={**os.environ, "LANG": "C"},
        )
    except Exception as e:
        print(f"[clamav_ctl] scan failed: {e}", file=sys.stderr)
        return 1
    duration = time.time() - started

    summary = _parse_summary(binary, r.stdout or "")
    summary["exit_code"] = r.returncode
    summary["duration_seconds"] = f"{duration:.3f}"
    findings = _collect_findings(r.stdout or "")

    infected_str = summary.get("infected_files", "0").split()[0]
    try:
        infected = int(infected_str)
    except Exception:
        infected = 0

    report = {
        "profile": profile_name,
        "timestamp_utc": ts_utc,
        "host": host,
        "engine": {
            "binary": path,
            "known_viruses": summary.get("known_viruses"),
            "engine_version": summary.get("engine_version"),
        },
        "summary": summary,
        "findings_raw": findings,
        "stderr": (r.stderr or "").strip() or None,
    }

    if output_basename:
        base = Path(output_basename)
    else:
        base = report_root / profile_name / _utc_stamp()
    base.parent.mkdir(parents=True, exist_ok=True)
    y_path = base.with_suffix(".yaml")
    with y_path.open("w", encoding="utf-8") as f:
        yaml.safe_dump(report, f, sort_keys=False, allow_unicode=True)
    print(f"Wrote {y_path}")

    if write_markdown:
        md_path = base.with_suffix(".md")
        md = _render_markdown(report)
        with md_path.open("w", encoding="utf-8") as f:
            f.write(md)
        print(f"Wrote {md_path}")

    return r.returncode if r.returncode != 0 else (1 if infected > 0 else 0)


def main() -> int:
    parser = argparse.ArgumentParser(description="ClamAV orchestrator (profiles + YAML reports).")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_check = sub.add_parser("check", help="Check ClamAV binaries and freshclam presence.")
    p_check.set_defaults(fn=lambda a: cmd_check())

    p_list = sub.add_parser("list-profiles", help="List available profiles.")
    p_list.add_argument("--profiles-dir", default=PROFILE_DIR_DEFAULT)
    p_list.set_defaults(fn=lambda a: cmd_list_profiles(Path(a.profiles_dir)))

    p_scan = sub.add_parser("scan", help="Run a scan for a profile and write YAML report.")
    p_scan.add_argument("--profile", required=True)
    p_scan.add_argument("--profiles-dir", default=PROFILE_DIR_DEFAULT)
    p_scan.add_argument("--report-root", default=REPORT_ROOT_DEFAULT)
    p_scan.add_argument("--output-basename", default=None)
    p_scan.add_argument("--repo-root", default=None, help="Optional working directory for scan.")
    p_scan.add_argument(
        "--write-markdown",
        action="store_true",
        help="Also write a human-readable markdown summary next to the YAML report.",
    )
    p_scan.set_defaults(
        fn=lambda a: cmd_scan(
            a.profile,
            Path(a.profiles_dir),
            Path(a.report_root),
            a.output_basename,
            Path(a.repo_root).resolve() if a.repo_root else None,
            a.write_markdown,
        )
    )

    args = parser.parse_args()
    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())


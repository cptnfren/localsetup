---
name: localsetup-clamav-orchestrator
description: "Python harness for ClamAV: check/install guidance, profile-based scans, YAML reports, and cron integration."
metadata:
  version: "1.0"
compatibility: "Linux server with ClamAV packages (clamav, clamav-daemon, clamav-freshclam). Python 3.10+ and PyYAML (framework)."
---

# ClamAV orchestrator

Manage ClamAV from this repo: check/install guidance, profile-based scans, compact YAML reports, and hooks for cron. ClamAV itself is installed via the OS package manager in standard locations; this repo owns profiles, reports, and automation.

## Profiles (av/profiles/*.yaml)

Each profile defines *what* to scan and *how*:

```yaml
profile: nightly-full
paths:
  - "/"
exclude_paths:
  - "/proc"
  - "/sys"
  - "/dev"
  - "/run"
use_clamd: false        # false = clamscan, true = clamdscan
extra_args: []          # extra flags, e.g. ["-i", "-o"]
```

- `paths`: list of root paths to scan.
- `exclude_paths`: paths to skip (mapped to `--exclude-dir`).
- `use_clamd`: when true, prefer `clamdscan` over `clamscan`.
- `extra_args`: passed as-is to the scanner binary (no shell expansion inside).

Profiles live under `av/profiles/`. Example: `av/profiles/nightly-full.yaml`.

## Reports (reports/clamav/)

Each scan writes a compact YAML record:

```yaml
profile: nightly-full
timestamp_utc: 2026-02-24T19:30:00Z
host: sh0t
engine:
  binary: /usr/bin/clamscan
summary:
  exit_code: 0
  scanned_files: 123456
  infected_files: 0
  duration_seconds: 842
  raw_summary: |
    Known viruses: ...
    Scanned files: ...
    Infected files: 0
findings_raw:
  - "/path/to/file: Eicar-Test-Signature FOUND"
```

Default layout (when `--output-basename` is not given):

- `reports/clamav/<profile>/<STAMP>.yaml` where `<STAMP>` is `YYYYmmddTHHMMSSZ`.

Markdown is optional and only added when explicitly requested in future extensions; default is compact YAML for machine readability.

## CLI (scripts/clamav_ctl.py)

Run from repo root (or pass `--repo-root`):

- **Check installation and DB:**

  ```bash
  python3 _localsetup/skills/localsetup-clamav-orchestrator/scripts/clamav_ctl.py check
  ```

  - Verifies presence of `clamscan` or `clamdscan` and `freshclam`.
  - If missing, prints install guidance (e.g. `sudo apt install clamav clamav-daemon clamav-freshclam`) and exits non-zero. Actual install must be run in a shared tmux session with sudo (see `localsetup-tmux-shared-session-workflow`).

- **List profiles:**

  ```bash
  python3 _localsetup/skills/localsetup-clamav-orchestrator/scripts/clamav_ctl.py list-profiles
  ```

- **Run a scan for a profile:**

  ```bash
  python3 _localsetup/skills/localsetup-clamav-orchestrator/scripts/clamav_ctl.py \
    scan --profile nightly-full
  ```

  - Uses `av/profiles/nightly-full.yaml`.
  - Picks `clamscan` or `clamdscan` based on `use_clamd` and what is installed.
  - Writes a YAML report under `reports/clamav/nightly-full/<STAMP>.yaml` and prints the path.

- **Custom output basename:**

  ```bash
  python3 _localsetup/skills/localsetup-clamav-orchestrator/scripts/clamav_ctl.py \
    scan --profile nightly-full \
    --output-basename "reports/clamav/nightly-full/20260224T193000Z"
  ```

  - Writes `...yaml` at the given base (no markdown by default).

## Cron integration (via localsetup-cron-orchestrator)

Add tasks to `cron/manifest.yaml` that call this harness. Example:

```yaml
triggers:
  nightly-av:
    schedule: "30 1 * * *"  # 01:30 UTC
tasks:
  - id: av-nightly-full
    trigger: nightly-av
    sequence_order: 1
    command: "python3 _localsetup/skills/localsetup-clamav-orchestrator/scripts/clamav_ctl.py scan --profile nightly-full"
    enabled: true
```

Use `localsetup-cron-orchestrator` to install and manage these cron entries.

## Patterns for agents

- When ClamAV is missing, run `check` first; follow the printed install commands inside a shared tmux session with sudo.
- When defining new profiles, keep them small and focused (e.g. `web-root`, `home-directories`, `critical-system`), then add cron tasks for each as needed.

